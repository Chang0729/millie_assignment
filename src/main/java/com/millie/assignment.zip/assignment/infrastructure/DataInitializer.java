package com.millie.assignment.infrastructure;

import com.millie.assignment.adapter.out.persistence.CouponJpaEntity;
import com.millie.assignment.adapter.out.persistence.CouponRepository;
import com.millie.assignment.adapter.out.persistence.ProductJpaEntity;
import com.millie.assignment.adapter.out.persistence.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final ProductRepository productRepository;
    private final CouponRepository couponRepository;

    @Override
    public void run(String... args) {
        // Init Products
        if (productRepository.count() == 0) {
            productRepository.save(ProductJpaEntity.builder()
                    .name("Smartphone")
                    .originalPrice(1000000)
                    .discountPercent(5) // 5% Sale
                    .category("Electronics")
                    .build());

            productRepository.save(ProductJpaEntity.builder()
                    .name("T-Shirt")
                    .originalPrice(30000)
                    .discountPercent(0)
                    .category("Clothing")
                    .build());
        }

        // Init Coupons
        if (couponRepository.count() == 0) {
            couponRepository.save(CouponJpaEntity.builder()
                    .code("WELCOME10")
                    .type(CouponJpaEntity.DiscountTypeJpa.PERCENTAGE)
                    .value(10) // 10%
                    .build());

            couponRepository.save(CouponJpaEntity.builder()
                    .code("SAVE5000")
                    .type(CouponJpaEntity.DiscountTypeJpa.AMOUNT)
                    .value(5000) // 5000 won
                    .build());
        }
    }
}
