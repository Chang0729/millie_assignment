package com.millie.assignment.adapter.in.web;

import com.millie.assignment.application.port.in.GetProductUseCase;
import com.millie.assignment.application.port.in.ProductResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/product")
@RequiredArgsConstructor
public class ProductController {
    private final GetProductUseCase getProductUseCase;

    @GetMapping
    public ResponseEntity<List<ProductResponse>> getAllProducts() {
        return ResponseEntity.ok(getProductUseCase.getAllProducts());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ProductResponse> getProductDetails(
            @PathVariable Long id,
            @RequestParam(required = false) Long couponId) {
        return ResponseEntity.ok(getProductUseCase.getProductDetails(id, couponId));
    }
}
