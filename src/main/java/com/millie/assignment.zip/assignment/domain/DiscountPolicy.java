package com.millie.assignment.domain;

public interface DiscountPolicy {
    long applyDiscount(long originalPrice);
}
