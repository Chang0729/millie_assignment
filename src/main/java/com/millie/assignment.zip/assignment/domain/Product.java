package com.millie.assignment.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Product {
    private Long id;
    private String name;
    private long originalPrice;
    private int discountPercent;
    private String category;

    public void validate() {
        if (originalPrice < 0) {
            throw new IllegalArgumentException("Price cannot be negative");
        }

        if (discountPercent < 0 || discountPercent > 100) {
            throw new IllegalArgumentException("Discount percent must be between 0 and 100");
        }

        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Product name cannot be empty");
        }
    }

    public long getSalePrice() {
        if(discountPercent == 0) return originalPrice;
        long discountAmount = (long) (originalPrice * (discountPercent / 100.0));
        return originalPrice - discountAmount;
    }

    public long calculateFinalPrice(DiscountPolicy coupon) {
        long basePrice = getSalePrice();
        if (coupon == null) {
            return basePrice;
        }
        return coupon.applyDiscount(basePrice);
    }
}
