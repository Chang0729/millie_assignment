package com.millie.assignment.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
@AllArgsConstructor
public class Coupon implements DiscountPolicy{
    private Long id;
    private String code;
    private DiscountType type;
    private int value;

    public enum DiscountType {
        PERCENTAGE, AMOUNT
    }

    @Override
    public long applyDiscount(long originalPrice) {
        if (type == DiscountType.AMOUNT) {
            return Math.max(0, originalPrice - value);
        } else if (type == DiscountType.PERCENTAGE) {
            long discountAmount = (long) (originalPrice * (value / 100.0));
            return Math.max(0, originalPrice - discountAmount);
        }
        return originalPrice;
    }
}
