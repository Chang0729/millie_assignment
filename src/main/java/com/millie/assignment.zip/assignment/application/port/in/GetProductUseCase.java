package com.millie.assignment.application.port.in;

import java.util.List;

public interface GetProductUseCase {
    List<ProductResponse> getAllProducts();
    ProductResponse getProductDetails(Long productId, Long couponId);
}
