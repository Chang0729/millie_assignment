package com.millie.assignment.application.port.in;

import com.millie.assignment.domain.Product;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ProductResponse {
    private Long id;
    private String name;
    private long originalPrice;
    private long finalPrice;
    private String category;

    public static ProductResponse from(Product product, long finalPrice) {
        return ProductResponse.builder()
                .id(product.getId())
                .name(product.getName())
                .originalPrice(product.getOriginalPrice())
                .finalPrice(finalPrice)
                .category(product.getCategory())
                .build();
    }

}
