package com.millie.assignment.application.service;

import com.millie.assignment.application.port.in.GetProductUseCase;
import com.millie.assignment.application.port.in.ProductResponse;
import com.millie.assignment.application.port.out.LoadCouponPort;
import com.millie.assignment.application.port.out.LoadProductPort;
import com.millie.assignment.domain.Coupon;
import com.millie.assignment.domain.Product;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)

public class ProductService implements GetProductUseCase {

    private final LoadProductPort loadProductPort;
    private final LoadCouponPort loadCouponPort;

    @Override
    public List<ProductResponse> getAllProducts() {
        return loadProductPort.loadAllProducts().stream()
                .map(product -> ProductResponse.from(product, product.getOriginalPrice()))
                .collect(Collectors.toList());
    }

    @Override
    public ProductResponse getProductDetails(Long productId, Long couponId) {
        Product product = loadProductPort.loadProduct(productId)
                .orElseThrow(() -> new IllegalArgumentException("Product not found"));

        long finalPrice = product.getOriginalPrice();

        if (couponId != null) {
            Coupon coupon = loadCouponPort.loadCoupon(couponId)
                    .orElseThrow(() -> new IllegalArgumentException("Coupon not found"));
            finalPrice = product.calculateFinalPrice(coupon);
        } else {
            // Even if no coupon, apply product discount
            finalPrice = product.getSalePrice();
        }

        return ProductResponse.from(product, finalPrice);
    }


}
